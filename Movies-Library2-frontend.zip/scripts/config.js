const config = {
    API_URL: "http://localhost:8989/auth",
    USER_URL: "http://localhost:8989/user",
    ADMIN_URL: "http://localhost:8989/admin",
    MOVIES_URL: "http://localhost:8989/movies",
    LISTS_URL: "http://localhost:8989/movies"

};